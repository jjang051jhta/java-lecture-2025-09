import java.util.Vector;

public class CollectionTest01 {
    public static void main(String[] args) {
        Vector<Integer> vector = new Vector<Integer>();
    }
}
