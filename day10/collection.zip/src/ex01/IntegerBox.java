package ex01;

public class IntegerBox {
    private Integer value;
    public void setValue(Integer value) {
        this.value = value;
    }
    public Integer getValue() {
        return value;
    }
}
