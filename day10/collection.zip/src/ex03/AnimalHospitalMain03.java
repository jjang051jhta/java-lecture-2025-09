package ex03;

import animal.Cat;
import animal.Dog;

public class AnimalHospitalMain03 {
    public static void main(String[] args) {
        AnimalHospital02<Dog> dogHospital = new AnimalHospital02<>();
        AnimalHospital02<Cat> catHospital = new AnimalHospital02<>();
        AnimalHospital02<Integer> intHospital = new AnimalHospital02<>();
        AnimalHospital02<String> strHospital = new AnimalHospital02<>();

    }
}
